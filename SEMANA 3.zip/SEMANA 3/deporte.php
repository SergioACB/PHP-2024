<?php   
if ($_POST){
    $peso=$_POST["peso"];
    $altura=$_POST["altura"];
    $nombre=$_POST["nombre"];
    $edad=$_POST["edad"];

    //Proceso de evaluacion de condicionales//
    if ($peso>=80 && $altura>= 1.80 && $edad>=18){
        echo "El estudiante ".$nombre." es aceptado en el equipo de Basketball"."<br>";
    }
    else{
        echo"El estudiante ".$nombre." No cumple los requisitos para entrar en el equipo de Basketball"."<br>";
    }
}
?>